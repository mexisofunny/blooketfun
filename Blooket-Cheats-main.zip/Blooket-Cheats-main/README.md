I used the old gui made by minesraft2 and added the newer modules to it.
Some things don't work though...

Credits to 05konz

Discord:https://discord.gg/jHjGrrdXP6
